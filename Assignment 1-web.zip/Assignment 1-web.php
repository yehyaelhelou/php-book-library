<?php

// ============================================================
// Q1. Smart Name Badge Generator
// Topics: [Strings] [Loops] [Date]
// ============================================================

$X = [
    "  Mohammed   Al-Hassan  ",
    "   Ali   ",
    " Fatima   Ibrahim   Zaqout ",
    "  Omar  Khaled  Abu Nada  ",
    "  Sara  "
];

for ($i = 0; $i < count($X); $i++) {
    $Y = trim($X[$i]);
    $Y = strtoupper($Y);
    $Z = str_replace(" ", "", $Y);
    if (strlen($Z) > 10) {
        echo $Y . " — " . date("l") . "\n";
    }
}

// ============================================================
// Q2. Birthday Countdown with Weekday Check
// Topics: [Date] [Strings] [Arithmetic]
// ============================================================

$X = "15-03";

$Y = strpos($X, "-");
$Z = substr($X, 0, $Y);
$W = substr($X, $Y + 1);

$Z = (int)$Z;
$W = (int)$W;

$V = (int)date("Y");

$T = mktime(0, 0, 0, $W, $Z, $V);

if ($T < time()) {
    $T = mktime(0, 0, 0, $W, $Z, $V + 1);
}

$X_days = (int)(($T - mktime(0, 0, 0, (int)date("m"), (int)date("d"), (int)date("Y"))) / 86400);

$X_dayNum = date("N", $T);
$X_dayName = date("l", $T);
$X_monthName = date("F", $T);
$X_year = date("Y", $T);

echo "\nNext birthday: " . $Z . "-" . $X_monthName . "-" . $X_year . "\n";
echo "Days remaining: " . $X_days . "\n";
echo "Falls on: " . $X_dayName . " — " . (($X_dayNum >= 6) ? "weekend!" : "weekday") . "\n";

// ============================================================
// Q3. Palindrome Multiplication Filter
// Topics: [Palindrome] [Loops] [Multiplication]
// ============================================================

$X = 11;

for ($Y = 10; $Y >= 1; $Y--) {
    if ($Y % 2 == 0) {
        continue;
    }

    $Z = $X * $Y;

    $W = (string)$Z;
    $V = strlen($W);
    $isPalin = true;
    for ($i = 0; $i < (int)($V / 2); $i++) {
        if ($W[$i] != $W[$V - 1 - $i]) {
            $isPalin = false;
            break;
        }
    }

    echo $X . " x " . $Y . " = " . $Z;
    if ($isPalin) {
        echo " [P]";
    }
    echo "\n";
}

// ============================================================
// Q4. Email Domain Extractor with Pattern Display
// Topics: [Strings] [Pattern] [Loops]
// ============================================================

$X = [
    "mohammed@gmail.com",
    "ali@iug.edu",
    "fatima.zaqout@yahoo.com",
    "ab@test.com",
    "omar.khaled@hotmail.com"
];

for ($i = 0; $i < count($X); $i++) {
    $Y = strpos($X[$i], "@");
    $Z = substr($X[$i], 0, $Y);
    $W = substr($X[$i], $Y + 1);
    $V = strlen($Z);

    if ($V < 4) {
        echo "Skipping: " . $X[$i] . " (username too short)\n";
        continue;
    }

    echo "Email: " . $X[$i] . "\n";
    echo "Username: " . $Z . " | Domain: " . $W . "\n";

    $N = $V;
    if ($N % 2 == 0) {
        $N = $N + 1;
    }

    $mid = (int)($N / 2) + 1;

    for ($r = 1; $r <= $N; $r++) {
        if ($r <= $mid) {
            $stars = $r;
        } else {
            $stars = $N - $r + 1;
        }

        $spaces = $mid - $stars;

        for ($s = 0; $s < $spaces; $s++) {
            echo " ";
        }

        if ($stars == 1) {
            echo "*";
        } else {
            echo "*";
            for ($s = 0; $s < 2 * $stars - 3; $s++) {
                echo " ";
            }
            echo "*";
        }
        echo "\n";
    }
    echo "\n";
}

// ============================================================
// Q5. Swap and Sequence Builder
// Topics: [Swap] [Even/Odd] [Sequence]
// ============================================================

$X = 20;
$Y = 1;

$X = $X + $Y;
$Y = $X - $Y;
$X = $X - $Y;

echo "After swap: X = " . $X . ", Y = " . $Y . "\n";

$Z = [];
$W = 0;

for ($i = $X; $i <= $Y; $i++) {
    if ($i % 3 == 0) {
        continue;
    }

    if ($i % 2 == 0) {
        $W++;
        if ($W % 4 == 0) {
            continue;
        }
    }

    $Z[] = $i;
}

echo implode("-", $Z) . "\n";

// ============================================================
// Q6. Next-Friday Countdown Calendar
// Topics: [Date] [Loops] [Pattern]
// ============================================================

echo "\nToday is: " . date("l, d-F-Y") . "\n";

$X = (int)date("N");

if ($X == 5) {
    $Y = 7;
} else {
    $Y = (5 - $X + 7) % 7;
    if ($Y == 0) {
        $Y = 7;
    }
}

echo "Days until next Friday: " . $Y . "\n\n";

for ($i = 0; $i <= $Y; $i++) {
    $Z = strtotime("+" . $i . " days");
    $W = date("l", $Z);
    $V = (int)date("N", $Z);

    echo $W;
    if ($i == 0) {
        echo " [TODAY]";
    }
    echo "\n";

    for ($j = 0; $j < $V; $j++) {
        echo "-";
    }
    echo "\n";
}

// ============================================================
// Q7. Full Pipeline — Name to Code to Verify
// Topics: [Strings] [Palindrome] [Multiplication] [Date]
// ============================================================

$X = "   Mohammed   Zaqalm   ";
$X = trim($X);
$X = strtoupper($X);

$Y = "";
$Z = strlen($X);
for ($i = 0; $i < $Z; $i++) {
    $W = $X[$i];
    if ($W != 'A' && $W != 'E' && $W != 'I' && $W != 'O' && $W != 'U') {
        $Y .= $W;
    }
}

echo "\nProcessed name: " . $Y . "\n";

$V = str_replace(" ", "", $Y);
$N = strlen($V);

echo "Character count: " . $N;

$X_dayN = (int)date("N");
if ($X_dayN == 5) {
    $X_fri = 7;
} else {
    $X_fri = (5 - $X_dayN + 7) % 7;
    if ($X_fri == 0) $X_fri = 7;
}

if ($N % 2 == 0) {
    echo " (even)\n";

    $W = (string)$N;
    $L = strlen($W);
    $isPalin = true;
    for ($i = 0; $i < (int)($L / 2); $i++) {
        if ($W[$i] != $W[$L - 1 - $i]) {
            $isPalin = false;
            break;
        }
    }
    echo $N . ($isPalin ? " is a palindrome." : " is not a palindrome.") . "\n";
    echo "Days until Friday: " . $X_fri . "\n";
    echo "Result: " . $N . "-" . $X_fri . "\n";
} else {
    echo " (odd)\n";
    $lastLine = "";
    for ($j = 10; $j >= 1; $j--) {
        if ($j % 2 == 0) continue;
        $result = $N * $j;
        $lastLine = $N . " x " . $j . " = " . $result;
        echo $lastLine . "\n";
    }
    echo "Days until Friday: " . $X_fri . "\n";
    echo "Result: " . $lastLine . "-" . $X_fri . "\n";
}

// ============================================================
// Q8. Number Grid with Diagonal Palindrome Scan
// Topics: [Loops] [Palindrome] [Pattern]
// ============================================================

echo "\n--- Number Grid 5x5 ---\n";

$X = [];
for ($i = 1; $i <= 5; $i++) {
    $X[$i] = [];
    for ($j = 1; $j <= 5; $j++) {
        $X[$i][$j] = $i * $j;
        echo str_pad($X[$i][$j], 4, " ", STR_PAD_LEFT);
    }
    echo "\n";
}

$Y = "";
for ($i = 1; $i <= 5; $i++) {
    $Y .= $X[$i][$i];
}

$Z = strlen($Y);
$isPalin = true;
for ($i = 0; $i < (int)($Z / 2); $i++) {
    if ($Y[$i] != $Y[$Z - 1 - $i]) {
        $isPalin = false;
        break;
    }
}

echo "Diagonal string: " . $Y . " — " . ($isPalin ? "palindrome!" : "not a palindrome") . "\n";

$W = [];
for ($i = 1; $i <= 5; $i++) {
    for ($j = 1; $j <= 5; $j++) {
        $V = $X[$i][$j];
        if ($V % 2 == 0) {
            $found = false;
            for ($k = 0; $k < count($W); $k++) {
                if ($W[$k] == $V) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $W[] = $V;
            }
        }
    }
}

sort($W);

$T = [];
$evenCount = 0;
for ($i = 0; $i < count($W); $i++) {
    $evenCount++;
    if ($evenCount % 3 == 0) {
        continue;
    }
    $T[] = $W[$i];
}

echo "Even numbers: " . implode("-", $T) . "\n";

// ============================================================
// Q9. Email Report with Birthday Cross-Check
// Topics: [Strings] [Date] [Loops]
// ============================================================

echo "\n--- Email Birthday Report ---\n";

$X = ["madam@test.com", "level@iug.edu", "ahmed@gmail.com", "sara@yahoo.com"];
$Y = ["25-12", "10-06", "01-09", "20-03"];

$Z_minDays = PHP_INT_MAX;
$Z_minName = "";

for ($i = 0; $i < count($X); $i++) {
    $W = strpos($X[$i], "@");
    $V = substr($X[$i], 0, $W);

    $L = strlen($V);
    $isPalin = true;
    for ($j = 0; $j < (int)($L / 2); $j++) {
        if ($V[$j] != $V[$L - 1 - $j]) {
            $isPalin = false;
            break;
        }
    }

    $dashPos = strpos($Y[$i], "-");
    $bDay = (int)substr($Y[$i], 0, $dashPos);
    $bMonth = (int)substr($Y[$i], $dashPos + 1);

    $curYear = (int)date("Y");
    $bDate = mktime(0, 0, 0, $bMonth, $bDay, $curYear);
    $today = mktime(0, 0, 0, (int)date("m"), (int)date("d"), $curYear);

    if ($bDate < $today) {
        $bDate = mktime(0, 0, 0, $bMonth, $bDay, $curYear + 1);
    }

    $daysLeft = (int)(($bDate - $today) / 86400);

    echo $X[$i] . " | Username: " . $V;
    if ($isPalin) {
        echo " [PALINDROME]";
    }
    echo " | Birthday in " . $daysLeft . " days\n";

    if ($daysLeft < $Z_minDays) {
        $Z_minDays = $daysLeft;
        $Z_minName = $V;
    }
}

echo "---\n";
echo "Soonest birthday: " . $Z_minName . " (" . $Z_minDays . " days)\n";

// ============================================================
// Q10. Grand Finale — The Complete PHP Dashboard
// Topics: [All Topics] [Logic] [Output]
// ============================================================

echo "\n=== PHP DASHBOARD ===\n";

// Section 1: Date and days until Friday
$X_dayN = (int)date("N");
if ($X_dayN == 5) {
    $X_fri = 7;
} else {
    $X_fri = (5 - $X_dayN + 7) % 7;
    if ($X_fri == 0) $X_fri = 7;
}
echo "Date: " . date("l, d-F-Y") . " | Days to Friday: " . $X_fri . "\n";
echo "========================\n";

// Section 2: Name processing
$X = "   Mohammed  Zaqalm   ";
$X = trim($X);
$X = strtoupper($X);

$Y = "";
$Z = strlen($X);
for ($i = 0; $i < $Z; $i++) {
    $W = $X[$i];
    if ($W != 'A' && $W != 'E' && $W != 'I' && $W != 'O' && $W != 'U') {
        $Y .= $W;
    }
}

$V = str_replace(" ", "", $Y);
$N = strlen($V);

$W_str = (string)$N;
$L = strlen($W_str);
$isPalin = true;
for ($i = 0; $i < (int)($L / 2); $i++) {
    if ($W_str[$i] != $W_str[$L - 1 - $i]) {
        $isPalin = false;
        break;
    }
}

echo "[Section 2] Name: " . $Y . " | Count: " . $N . " | Palindrome: " . ($isPalin ? "YES" : "NO") . "\n";
echo "========================\n";

// Section 3: Multiplication table
$X = 7;
echo "[Section 3] Multiplication table for " . $X . " (odd multipliers, 10 down to 1):\n";
for ($Y = 10; $Y >= 1; $Y--) {
    if ($Y % 2 == 0) continue;
    $Z = $X * $Y;

    $W = (string)$Z;
    $L = strlen($W);
    $isPalin = true;
    for ($i = 0; $i < (int)($L / 2); $i++) {
        if ($W[$i] != $W[$L - 1 - $i]) {
            $isPalin = false;
            break;
        }
    }

    echo $X . " x " . $Y . " = " . $Z;
    if ($isPalin) echo " [P]";
    echo "\n";
}
echo "========================\n";

// Section 4: Even numbers 0-50 skipping every 3rd
echo "[Section 4] Even numbers 0-50 (skip every 3rd):\n";
$Z = [];
$W = 0;
for ($i = 0; $i <= 50; $i += 2) {
    $W++;
    if ($W % 3 == 0) continue;
    $Z[] = $i;
}
echo implode("-", $Z) . "\n";
echo "========================\n";

// Section 5: Email username extraction
$X = "omar.khaled@hotmail.com";
$Y = strpos($X, "@");
$Z = substr($X, 0, $Y);
$W = substr($X, $Y + 1);
echo "[Section 5] Email: " . $X . " | Username: " . $Z . " | Domain: " . $W . "\n";
echo "========================\n";

// Section 6: Swap two numbers
$X = 55;
$Y = 30;
echo "[Section 6] Before swap: X = " . $X . ", Y = " . $Y . "\n";
$X = $X + $Y;
$Y = $X - $Y;
$X = $X - $Y;
echo "[Section 6] After swap:  X = " . $X . ", Y = " . $Y . "\n";
echo "========================\n";

// Section 7: Hollow diamond
$V_noSpace = str_replace(" ", "", "MHMMD ZQLM");
$N = strlen($V_noSpace);
if ($N > 9) $N = 9;
if ($N % 2 == 0) $N = $N - 1;

echo "[Section 7] Hollow Diamond (height = " . $N . "):\n";

$mid = (int)($N / 2) + 1;
for ($r = 1; $r <= $N; $r++) {
    if ($r <= $mid) {
        $stars = $r;
    } else {
        $stars = $N - $r + 1;
    }
    $spaces = $mid - $stars;

    for ($s = 0; $s < $spaces; $s++) {
        echo " ";
    }
    if ($stars == 1) {
        echo "*";
    } else {
        echo "*";
        for ($s = 0; $s < 2 * $stars - 3; $s++) {
            echo " ";
        }
        echo "*";
    }
    echo "\n";
}
echo "========================\n";

// Section 8: Numbers 1-30 skipping multiples of 4
echo "[Section 8] Numbers 1-30 (skip multiples of 4):\n";
$Z = [];
for ($i = 1; $i <= 30; $i++) {
    if ($i % 4 == 0) continue;
    $Z[] = $i;
}
echo implode("-", $Z) . "\n";
echo "========================\n";

echo "=== END OF DASHBOARD ===\n";

?>
